Import Invoice Multi Payments:
=================================

Go to Setting / App and search "Import Invoice Multi Payments" and Install

And, you are done with installation. Congratulations!
