# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2015 DevIntelle Consulting Service Pvt.Ltd (<http://www.devintellecs.com>).
#
#    For Module Support : devintelle@gmail.com  or Skype : devintelle 
#
##############################################################################

from odoo import api, fields, models, _
import base64
import csv
from io import StringIO
from odoo.tools.translate import _
from odoo.exceptions import ValidationError
import itertools
from operator import itemgetter
import operator
import logging
_logger = logging.getLogger(__name__)


class dev_import_payment(models.TransientModel):
    _name = "dev.import.payment"

    import_file = fields.Binary('File',filters='*.csv')
    
    _required_columns = ['unique_id','invoice_number', 'document_number', 'customer_name', 'payment_date', 'payment_type', 'journal', 'invoice_payment', 'total_payment']
    _column_indexes = {}
    
    def load_column_indexes(self, line):
        cols = self._required_columns.copy()
        index = 0;
        for column_name in line:
            column_name = column_name.lower()
            cols.remove(column_name)
            self._column_indexes[column_name] = index
            index += 1
        if len(cols) > 0:
            raise ValueError('The CSV file does not contains the mandatory fields: ' + str(cols))
    
    def get_field_value(self, line, column_name):
        result = None
        if column_name in self._column_indexes:
            index = self._column_indexes[column_name]
            result = line[index]
            return result
            
    @api.multi
    def get_partner_id(self,name):
        partner_id = self.env['res.partner'].search([('name','=',name)],limit=1)
        return partner_id.id
    
    @api.multi
    def get_invoice(self,number):
        if self._context.get('type') == 'customer':
            invoice = self.env['account.invoice'].search([('number','=',number),('type','in',['out_invoice','out_refund'])],limit=1)
        else:
            invoice = self.env['account.invoice'].search([('number','=',number),('type','in',['in_invoice','in_refund'])],limit=1)
        return invoice
        
    @api.multi
    def get_journal_id(self,name):
        journal_id = self.env['account.journal'].search([('name','=',name)],limit=1)
        return journal_id.id
    
    @api.multi
    def get_payment_method_id(self,name,p_type):
        method_id = self.env['account.payment.method'].search([('name','=',name),('payment_type','=',p_type)],limit=1)
        return method_id.id
    
    @api.multi
    def get_payment_values(self,line):
        if line:
            invoice = self.get_invoice(line.get('invoice_number'))
            payment_type = 'outbound'
            partner_type = 'supplier'
            if self._context.get('type') == 'customer':
                payment_type = 'inbound'
                partner_type = 'customer'

            vals={
                'payment_type':payment_type,
                'partner_type':partner_type,
                'payment_for':'multi_payment',
                'amount':float(line.get('total_payment')),
                'currency_id':invoice.currency_id.id,
                'journal_id':self.get_journal_id(line.get('journal')),
                'partner_id':self.get_partner_id(line.get('customer_name')),
                'payment_method_id':self.get_payment_method_id(line.get('payment_type'),payment_type),
                'payment_date': line.get('payment_date'),
                'communication': line.get('document_number'),
            }
            return vals
            
    @api.multi
    def get_payment_line_val(self,line,payment_id):
        invoice = self.get_invoice(line.get('invoice_number'))
        val = {'invoice_id': invoice.id, 'account_id': invoice.account_id.id,
               'date': invoice.date_invoice, 'due_date': invoice.date_due,
               'original_amount': invoice.amount_total, 
               'balance_amount': invoice.residual,
               'allocation': line.get('invoice_payment'), 
               'full_reconclle': False, 
               'account_payment_id':payment_id.id,
               'currency_id': invoice.currency_id.id,
               }
        if float(line.get('invoice_payment')) >= float(invoice.residual):
            val.update({
                'full_reconclle': True, 
            })
        return val
         
    
    @api.multi
    def create_payment(self,line):
        if line['values'][0]:
            pay_val = self.get_payment_values(line['values'][0])
            if pay_val:
                payment_id = self.env['account.payment'].create(pay_val)
                if payment_id:
                    for l in line.get('values'):
                        line_val = self.get_payment_line_val(l,payment_id)
                        self.env['advance.payment.line'].create(line_val)
            payment_id.post()
            return payment_id
    
    
    @api.multi
    def check_line(self,lines):
        f_notes=''
        total_amount = lines['values'][0].get('total_payment')
        l_no = ''
        amt=0
        for line in lines.get('values'):
            if l_no:
                l_no = str(l_no) + ', '+str(line.get('line_no'))
            else:
                l_no = str(line.get('line_no'))
                
            amt += float(line.get('invoice_payment'))
            csv_line_no = 'Line No: '+ str(line.get('line_no'))+' :'
            notes = ''
            invoice = self.get_invoice(line.get('invoice_number'))
            if not invoice:
                notes ='Invoice Not found'
            else:
                if invoice.state != 'open':
                    notes = 'Invoice Not open'
                elif float(line.get('invoice_payment')) > float(invoice.residual):
                    notes = 'Invoice '+str(line.get('invoice_number'))+' Amount must be less or equal to '+ str(invoice.residual)
                    
            partner_id = self.get_partner_id(line.get('customer_name'))
            if not partner_id:
                if notes:
                    notes = notes + ', '+'Customer Not Found'
                else:
                    notes = 'Customer Not Found'
            
            journal_id = self.get_journal_id(line.get('journal'))
            if not journal_id:
                if notes:
                    notes = notes + ', '+'Journal Not Found'
                else:
                    notes = 'Journal Not Found'

            payment_type = 'outbound'
            if self._context.get('type') == 'customer':
                payment_type = 'inbound'
            payment_method = self.get_payment_method_id(line.get('payment_type'),payment_type)
            
            if not payment_method:
                if notes:
                    notes = notes +', '+'Payment Method Not Found'
                else:
                    notes = 'Payment Method Not Found'
                    
            try:
                float(line.get('invoice_payment'))
            except ValueError:
                if notes:
                    notes = notes + ', ' +'Paid amont must be integer or float'
                else:
                    notes = 'Paid amont must be integer or float'

            if notes:
                _logger.info("\n====Import Logs ==>  "+csv_line_no + notes)
                if f_notes:
                    f_notes = f_notes + '\n' + csv_line_no + notes
                else:
                    f_notes = csv_line_no + notes       
        
        if float(amt) != float(total_amount):
            msg= "Amount not match in "+l_no +' Line number'
            if f_notes:
                
                f_notes = f_notes + '\n'+ msg
                _logger.info("\n====Import Logs ==>  "+msg)
            else:
                f_notes = msg
        
        if f_notes:
            return f_notes
            
        return 'ok' 

    @api.multi
    def import_payment(self):
        if not self.import_file:
            raise ValidationError(_('Please Import Payment File !'))
        readCSV = self.import_file and base64.decodestring(self.import_file) or False
        fdata = str(readCSV, 'utf-8')
        input = StringIO(fdata)
        input.seek(0)
        data = list(csv.reader(input, quotechar='"' or '"' or 'rU', delimiter=',',dialect='excel'))
        cnt=0
        notes = ''
        lst_data =[]
        for csv_line in data:
            cnt+=1
            if cnt == 1:
                self.load_column_indexes(csv_line)
                continue
            else:
                lst_data.append({
                    'unique_id':self.get_field_value(csv_line, 'unique_id'),
                    'invoice_number':self.get_field_value(csv_line, 'invoice_number'),
                    'document_number':self.get_field_value(csv_line, 'document_number'),
                    'customer_name':self.get_field_value(csv_line, 'customer_name'),
                    'payment_date':self.get_field_value(csv_line, 'payment_date'),
                    'payment_type':self.get_field_value(csv_line, 'payment_type'),
                    'journal':self.get_field_value(csv_line, 'journal'),
                    'invoice_payment':self.get_field_value(csv_line, 'invoice_payment'),
                    'total_payment':self.get_field_value(csv_line, 'total_payment'),
                    'line_no':cnt,
                    
                })
        if lst_data:
            n_lines=sorted(lst_data,key=itemgetter('unique_id'))
            groups = itertools.groupby(n_lines, key=operator.itemgetter('unique_id'))
            lst_data = [{'unique_id':k,'values':[x for x in v]} for k, v in groups] 
            
        payment_ids=[]
        for line in lst_data:
            check = self.check_line(line)
            if check == 'ok':
                payment_id = self.create_payment(line)
                payment_ids.append(payment_id.id)
            else:
                notes = notes +'\n'+check
                
        if notes:
            pay_type = self._context.get('type')
            log_id=self.env['dev.import.payment.log'].create({'name':notes, 'payment_ids':[(6,0, payment_ids)],'type':pay_type})
            return {
                'view_mode': 'form',
                'res_id': log_id.id,
                'res_model': 'dev.import.payment.log',
                'view_type': 'form',
                'type': 'ir.actions.act_window',
                'target': 'new',
            }
        else:
            if self._context.get('type') == 'customer':
                action = self.env.ref('account.action_account_payments').read()[0]
            else:
                action = self.env.ref('account.action_account_payments_payable').read()[0]

            if payment_ids:
                action['domain'] = [('id', 'in', payment_ids)]
            else:
                action = {'type': 'ir.actions.act_window_close'}
            return action
        
        return True

class import_payment_log(models.TransientModel):
    _name = "dev.import.payment.log"
    
    name = fields.Text('Logs')
    type = fields.Char('Type')
    payment_ids = fields.Many2many('account.payment',string='Payments')


    @api.multi
    def action_view_payment(self):
        if self.type == 'customer':
            action = self.env.ref('account.action_account_payments').read()[0]
        else:
            action = self.env.ref('account.action_account_payments_payable').read()[0]

        if self.payment_ids:
            action['domain'] = [('id', 'in', self.payment_ids.ids)]
        else:
            action = {'type': 'ir.actions.act_window_close'}
        return action

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
